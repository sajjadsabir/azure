#Production Settings

DEBUG = False
ALLOWED_HOSTS = ['.divorcecalcs.com']
DEBUG_LOG = False
DEBUG_DB_LOG = False
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
