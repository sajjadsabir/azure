Use this directory for misc utils: mainly helpers that are used in multiple django applications
