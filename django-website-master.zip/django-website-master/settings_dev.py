# Development Settings

DEBUG = True
ALLOWED_HOSTS = ['127.0.0.1','localhost']
DEBUG_LOG = True
DEBUG_DB_LOG = True
DEBUG_ALLOW_NON_UNIQUE_EMAIL = False
