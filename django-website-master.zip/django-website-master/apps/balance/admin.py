from django.contrib import admin

from .models import MonthlyBalance

admin.site.register(MonthlyBalance)
