python -m site_repo.apps.tasks_queue.service-start &
echo "Tasks server started"
