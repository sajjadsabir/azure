Use this directory for customized django components:
Middleware
Authentication backends
Custom context processors
Storage backends
Uploads handles
etc.
