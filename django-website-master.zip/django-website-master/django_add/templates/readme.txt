Django requires an app, and list it in INSTALLED_APP to load a template tag
