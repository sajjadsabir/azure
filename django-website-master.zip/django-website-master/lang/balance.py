cleared = "%s cleared this month balance"
not_cleared = "%s didn't clear this month balance"