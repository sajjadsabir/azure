

welcome_mail= {'subject':'Welcome!',
               'message':"""
               You successfuly signed up to divorcecalcs.
               We want to make these calcs as easy and smooth and possible"""}
                
                
reset_password_request = {'subject':'Reset Password Request',
                          'message':"""
                          Somone, we hope you, asked to reset your password.
                          If you did, please click the following link and reset.
                          {url}
                          If it's not you, ignore this mail. For any question please contact us.
                          Regards,
                          The DivorceCalcs Team"""}