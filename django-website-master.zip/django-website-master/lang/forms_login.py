#help_text
mail_approve = "Send me an email notification when divorcee approves an expense"
mail_balance = "Send me an  email notification when divorcee clears a month"
base_participate="Default % of divorcee participate in my expenses"


#error messages
password_not_match = "The two passwords do not match"

