# messages
sign_in_fail = "Wrong username or password"
reset_password_link_sent = "A reset password link was sent to you(if you provided a correct username or email). Check your mail"


# helptext
signup_account_code="If your divorcee already opened an account, please enter this account code"